#include <cstdlib>
#include <stdint.h>
#include <RTE_components.h>

typedef uint32_t U32;
typedef uint8_t U8;
#define WRITE(BASE,OFFSET,VALUE) *((U32 *) (BASE + OFFSET)) = VALUE

#define CLK_SPEED 20000000

int main_led_test (void) {
	U32 counter = 0;
	U32 counter_limit = 1000000;
	
	U8 led_val = 1;
	U32 led_addr = 0x40001000;
	WRITE(led_addr, 0x0, led_val);
	while (1) {
		if (counter >= counter_limit) {
			led_val = led_val << 1;
			if (led_val == 0) {
				led_val = 1;
			}
			WRITE(led_addr, 0x0, led_val);
			counter = 0;
		}
		counter = counter + 1;
	}
	return EXIT_SUCCESS;
}



int main_recv_test (void) {
	U32 led_addr = 0x40001000;
	U32 led_val = 0xF;
	U32 nipcb_addr = 0x40000000;
	U32 nipcb_cntr = 0;
	
	// turn on 4 leds
	led_val = 0x0F;
	WRITE (led_addr,0x0,led_val);
	
	// while (1);
		
	// configure recording
	WRITE (nipcb_addr,0x2C,0xF); // channel select all
	
	// while (1);
	
	WRITE (nipcb_addr,0x30,0xA); // stall time 10 cycles
	WRITE (nipcb_addr,0x34,0x5); // pga gain 101
	
	// start recording
	WRITE (nipcb_addr,0x0,0x2); // record trigger
	
	// let run for some time
	nipcb_cntr = 50;
	while (--nipcb_cntr)
		;
	
	while (1) // LOOOK HEREEE
		;
	
	// stop recording
	WRITE (nipcb_addr,0x0,0x2); // record trigger
	
	// re-configure recording 2 channels
	WRITE (nipcb_addr,0x2C,0x9); // channel 1 and 4
	
	// start recording
	WRITE (nipcb_addr,0x0,0x2); // record trigger
	
	// let run for some time
	nipcb_cntr = 50;
	while (--nipcb_cntr)
		;
	
	// stop recording
	WRITE (nipcb_addr,0x0,0x2); // record trigger

	// configure stimulation
	WRITE (nipcb_addr,0xC,0x0); // stim on channel 1
	WRITE (nipcb_addr,0x10,0x14); // cycles high
	WRITE (nipcb_addr,0x14,0x14); // cycles low
	WRITE (nipcb_addr,0x18,0x14); // cycles delay
	WRITE (nipcb_addr,0x1C,0x64); // cycles stall
	WRITE (nipcb_addr,0x20,0x02); // cycles count
	WRITE (nipcb_addr,0x24,0x8F); // high mag
	WRITE (nipcb_addr,0x28,0x70); // low mag
	
	// start recording
	WRITE (nipcb_addr,0x0,0x02);
	
	// let run for some time
	nipcb_cntr = 50;
	while (--nipcb_cntr)
		;
	
	// start stimulation
	WRITE (nipcb_addr,0x0,0x01);
	
	// let run
	nipcb_cntr = 50;
	while (--nipcb_cntr)
		;
	
	// stop recording
	WRITE (nipcb_addr,0x0,0x02);

	// let run
	nipcb_cntr = 50;
	while (--nipcb_cntr)
		;
	
	// start recording
	WRITE (nipcb_addr,0x0,0x02);
	
	// let run
	nipcb_cntr = 50;
	while (--nipcb_cntr)
		;
	
	// stop everything
	WRITE (nipcb_addr,0x0,0x03);
	
	// let run
	nipcb_cntr = 50;
	while (--nipcb_cntr)
		;
	
	// end by setting led
	WRITE (led_addr, 0x0, 0xFF);
	
	while (1)
		;
	
	return EXIT_SUCCESS;
}





int main_stim_and_recv_test (void) {
	U32 led_addr = 0x40001000;
	U32 nipcb_addr = 0x40000000;

	// configure stimulation (set up for 20MHz) (creates 40Hz)
	WRITE (nipcb_addr,0xC,0x0); // stim on channel 1
	WRITE (nipcb_addr,0x10,0x0003d090); // cycles high (250,000 cycles)
	WRITE (nipcb_addr,0x14,0x0003d090); // cycles low (250,000 cycles)
	WRITE (nipcb_addr,0x18,0x0003d090); // cycles delay (250,000 cycles)
	
	WRITE (nipcb_addr,0x1C,0x00d59f80); // cycles stall (14,000,000 cycles)
	
	WRITE (nipcb_addr,0x20,0x08); // cycles count
	
	WRITE (nipcb_addr,0x24,0xC0); // high mag
	WRITE (nipcb_addr,0x28,0x40); // low mag
	
	// configure recording
	WRITE (nipcb_addr,0x2C,0x1); // select all channels (high bit encoded)
	WRITE (nipcb_addr,0x30,0x64); // stall time (100 cycles)
	WRITE (nipcb_addr,0x34,0x1); // pga gain 001
	
	U32 counter = 0;
	U32 counter_limit = 10 * 20000000;
	bool polarity = 1;
	while (1) {
		if (polarity) {
			// start stimulation
			WRITE (nipcb_addr,0x0,0x01);
		} else {
			// start recording
			WRITE (nipcb_addr,0x0,0x02);
		}
		
		// wait a bit
		counter = counter_limit;
		while (--counter)
			;
		
		// end current process
		if (polarity) {
			// end stimulation
			WRITE (nipcb_addr,0x0,0x01);
		} else {
			// end recording
			WRITE (nipcb_addr,0x0,0x02);
		}
		
		// swap
		// polarity = !polarity;
	}

	while (1)
		;
	return EXIT_SUCCESS;
}

int main (void) {
	return main_stim_and_recv_test ();
}